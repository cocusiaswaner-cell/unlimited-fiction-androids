# Unlimited Fiction WebView wrapper intentionally keeps shrinking disabled by default.
