# Unlimited Fiction Android Wrapper

This project packages the live Unlimited Fiction website as an installable Android APK.

Live site:
https://unlition.netlify.app/

## What this wrapper handles

- Loads the current Unlimited Fiction website in Android WebView.
- JavaScript + DOM storage enabled for the React/Supabase app.
- Cookie handling enabled for web authentication/session state.
- Android Back button navigates WebView history before exiting.
- HTML file/image selection is supported through the Android file picker.
- Downloads from the website are handed to Android Download Manager.
- No Netlify AI credits are used by this Android build.

## Phone-only build using GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository.
3. Open the **Actions** tab.
4. Select **Build Unlimited Fiction APK**.
5. Tap **Run workflow**.
6. After the workflow finishes, open the run and download the artifact named `unlimited-fiction-debug-apk`.
7. Extract it and install `app-debug.apk` on Android.

The debug APK is signed by Android's standard debug signing setup during the build and is intended for direct testing, not Play Store publication.

## Release APK

For Play Store or long-term distribution, create a release signing key and configure a release signing config. Do not commit the keystore or passwords to GitHub.
